#
# Example shell file for starting PhoenixMiner.exe to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool ssl://eu1.ethermine.org:5555 -pool2 ssl://us1.ethermine.org:5555 -wal 0x093757b0d0f24a0362a31fad841698fc0ccad3e2.natta
